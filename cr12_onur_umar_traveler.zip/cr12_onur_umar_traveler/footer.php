<div class="mt-5 pt-5">
    <hr>
    <div class="container wrapper">

        <nav class="navbar navbar-expand-md navbar-light bg-white" role="navigation">
            <div class="container">
                <div class="navbar-nav mx-auto">
                <?php
                wp_nav_menu( array(
                    'theme_location'    => 'footer',
                    'depth'             => 1,
                    'container'         => 'div',
                    'container_class'   => 'collapse navbar-collapse',
                    'container_id'      => 'bs-example-navbar-collapse-1',
                    'menu_class'        => 'nav navbar-nav',
                    'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
                    'walker'            => new WP_Bootstrap_Navwalker(),
                ) );
                ?>
                </div>
            </div>
        </nav>

        <div class="container my-2 text-center">
            <div class="col-md-12">
                <a href="<?php echo home_url(); ?>">
                    <img class=" d-block img-fluid logo-banner" src="<?php the_custom_logo(); ?>" alt="">
                </a>
                <h3 class="text-center font-weight-light"><?php bloginfo();?></h3>
            </div>

        </div>


        <div class="text-center socialmedia mb-0">
            <a href=""> <i class="fa fa-facebook" aria-hidden="true"> </i></a>
            <a href=""> <i class="fa fa-pinterest-p" aria-hidden="true"> </i></a>
            <a href=""> <i class="fa fa-twitter" aria-hidden="true"> </i></a>
            <a href=""> <i class="fa fa-instagram" aria-hidden="true"> </i></a>
            <a href=""> <i class="fa fa-linkedin" aria-hidden="true"></i></a>
            <a href=""> <i class="fa fa-envelope-o" aria-hidden="true"></i></a>
            <a href=""><i class="fa fa-share" aria-hidden="true"></i></a>
        </div>
        <hr class="col-4 mt-0">
        <div class="mx-auto text-center mt-3">
            <p>the wordpress template</p>
        </div>
    </div>

</div>


<?php wp_footer(); ?>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
        integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
        crossorigin="anonymous"></script>
</body>
</html>