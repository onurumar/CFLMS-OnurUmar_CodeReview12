<?php get_header();?>

<div class="container">
    <div class="row">

        <?php if (is_active_sidebar('page-sidebar')): ?>
            <div class="d-none d-lg-block col-lg-3">
                <?php dynamic_sidebar('page-sidebar'); ?>
            </div>
            <div class="col-lg-9">
                <?php if(has_post_thumbnail()):?>
                    <img src="<?php the_post_thumbnail_url('blog-large');?>" alt="<?php the_title();?>" class="img-fluid mb-3">
                <?php endif;?>
                <?php get_template_part('includes/section', 'content'); ?>
            </div>
            <div class="d-sm-block d-lg-none mx-auto">
                <hr>
                <?php dynamic_sidebar('blog-sidebar'); ?>
            </div>
        <?php else: ?>


            
            </div>
        <?php endif; ?>


    </div>
</div>

<?php get_footer();?>


