<?php get_header(); ?>

    <div class="container">
        <div class="row">

            <?php if (is_active_sidebar('blog-sidebar')): ?>
                <div class="d-none d-lg-block col-lg-3">
                    <?php dynamic_sidebar('blog-sidebar'); ?>
                </div>
                <div class="col-lg-9">
                    <?php get_template_part('includes/section', 'blogcontent'); ?>
                </div>
                <div class="d-sm-block d-lg-none mx-auto">
                    <hr>
                    <?php dynamic_sidebar('blog-sidebar'); ?>
                </div>
            <?php else: ?>


                <div class="">
                    <?php get_template_part('includes/section', 'blogcontent'); ?>
                </div>
            <?php endif; ?>

        </div>
    </div>

<?php get_footer(); ?>