<?php get_header('landing'); ?>

    <div class="container">
        <div class="row ">

            <div class="img-fluid mx-auto">
                <?php get_template_part('includes/section', 'content'); ?>
            </div>

        </div>
    </div>


<?php get_footer(); ?>